<?php
session_start();
require_once('db_connection.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$title = $_POST['title'];
$description = $_POST['description'];
$category = $_POST['category'];
$price = $_POST['price'];
$username = $_SESSION['username'];
$today = date("Y-m-d");
$sql = "SELECT COUNT(*) as count FROM items WHERE username = '$username' AND post_date = '$today'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($row['count'] >= 3) {
    echo "You have already added 3 items today. Please try again tomorrow.";
    exit();
}
// Insert the item into the database
$sql = "INSERT INTO items (title, description, category, price, username, post_date) VALUES ('$title', '$description', '$category', $price, '$username', '$today')";

if ($conn->query($sql) === TRUE) {
    echo "Item posted successfully.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();

?>
