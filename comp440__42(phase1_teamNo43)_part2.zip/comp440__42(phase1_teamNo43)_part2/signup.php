<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('https://media.istockphoto.com/id/1286825422/vector/futuristic-online-shopping-e-commerce-concept-with-glowing-smartphone-shopping-cart-credit.jpg?s=612x612&w=0&k=20&c=PSJSmwBuy8_fpXqkVcVmamNlDeFJhtSLzOx45O3HOso=');
           
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            width: 400px;
            padding: 20px;
            text-align: center;
            opacity:0.9;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 15px;
            margin: 6px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .error-message {
            color: #ff0000;
        }

        .button-container {
            text-align: center;
        }

        .button {
            padding: 15px 20px;
            
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        .button:hover {
            background-color: #00ff00;
        }

        .signin-link {
            margin-top: 10px;
            display: block;
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .signin-link:hover {
            text-decoration: underline;
        }


        .name-container 
        {
            display: flex;
            justify-content: space-between;
         }

        .name-container input {
            flex: 0.8;
            margin-right: 5px;
        }

        .form-group {
    margin-bottom: 10px;
}

.input-container {
    display: flex;
    align-items: center;
}

label {
    width: 150px;
    margin-right: 10px;
}

input[type="text"],
input[type="password"] {
    flex: 1;
}
.form-label {
    font-weight: bold;
    font-size: 1.2em; 
}


    </style>
</head>
<body>
    <div class="container">
    <?php
     if(isset($_GET["error"])) {
        if($_GET["error"] ==1){
        echo "<p style='color:red;'>username is already taken, please try again !</p><br>";}
        if($_GET["error"] ==2){
            echo "<p style='color:red;'>emailid is already registered, please try again !</p><br>";}}
        ?>
        <h2>User registration</h2>

        <form id="registration-form" action="database.php" method="post">
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" placeholder="Enter First Name" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" placeholder="Enter Last Name" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter Username" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter Password" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="confirmPassword">Confirm Password:</label>
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Retype Password" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-container">
            <label class="form-label" for="email">Email:</label>
            <input type="text" id="email" name="email" placeholder="Enter Email" required>
        </div>
    </div>
    <p class="error-message" id="error-message"></p>
    <div class="button-container">
        <button type="button" class="button" onclick="validateForm()">Sign Up</button>
        <a href="login.php" class="signin-link">Already a user? Login</a>
    </div>
</form>

    </div>

    <script>
    function validateForm() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const errorMessage = document.getElementById('error-message');

        // Clear any previous error messages
        errorMessage.textContent = '';

        function isStrongPassword(password) {
        // Check if the password has at least 8 characters
        if (password.length < 8) {
            return false;
        }

        // Check if the password contains at least one uppercase letter
        if (!/[A-Z]/.test(password)) {
            return false;
        }

        // Check if the password contains at least one lowercase letter
        if (!/[a-z]/.test(password)) {
            return false;
        }

        // Check if the password contains at least one digit (number)
        if (!/\d/.test(password)) {
            return false;
        }

        // Check if the password contains at least one special character
        if (!/[!@#$%^&*()-=_+[\]{}|;:'",.<>?`~]/.test(password)) {
            return false;
        }

        return true;
    }

        // Validation checks
        if (username === '') {
            errorMessage.textContent = 'Username is required';
            return false;
        }

        // Strong password validation
        if (!isStrongPassword(password)) {
            errorMessage.textContent = 'Password must be at least 8 characters long and include uppercase, lowercase, a digit, and a special character.';
            return false;
        }

        if (password !== confirmPassword) {
            errorMessage.textContent = 'Unmatching Passwords';
            return false;
        }

        if (firstName === '') {
            errorMessage.textContent = 'First Name is required';
            return false;
        }

        if (lastName === '') {
            errorMessage.textContent = 'Last Name is required';
            return false;
        }

        // Basic email validation using a regular expression
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!email.match(emailPattern)) {
            errorMessage.textContent = 'Invalid email ID';
            return false;
        }

        // If all validations pass, you can submit the form to the server
        document.getElementById('registration-form').submit();
    }

    
</script>

</body>
</html>
