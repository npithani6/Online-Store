<?php
session_start();
require_once('db_connection.php');
require('header.php');
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if a category is provided in the GET request
    if (isset($_GET['category'])) {
        $category = $_GET['category'];

        // Query items based on the provided category
        $categorySql = "SELECT * FROM items WHERE category LIKE '%$category%'";
        $categoryResult = $conn->query($categorySql);
    } else {
        // Query all items initially
        $sql = "SELECT * FROM items";
        $allItemsResult = $conn->query($sql);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Results</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <h1>Search Results</h1>
    <form method="get">
        <label for="category">Category:</label>
        <input type="text" name="category" required>
        <input type="submit" value="Search">
    </form>

    <?php
    if (isset($categoryResult) && $categoryResult->num_rows > 0) {
        echo "<h2>Search Results for Category: $category</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Title</th><th>Description</th><th>Category</th><th>Price</th><th>Action</th></tr>";
        while ($row = $categoryResult->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['title'] . "</td>";
            echo "<td>" . $row['description'] . "</td>";
            echo "<td>" . $row['category'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td><a href='write_review.php?id=" . $row['id'] . "'>Write Review</a></td>"; // Add a link to the review page
            echo "</tr>";
        }
        echo "</table>";
    } elseif (isset($allItemsResult) && $allItemsResult->num_rows > 0) {
        echo "<h2>All Items</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Title</th><th>Description</th><th>Category</th><th>Price</th><th>Action</th></tr>";
        while ($row = $allItemsResult->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['title'] . "</td>";
            echo "<td>" . $row['description'] . "</td>";
            echo "<td>" . $row['category'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td><a href='write_review.php?id=" . $row['id'] . "'>Write Review</a></td>"; // Add a link to the review page
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No items found.";
    }
    ?>
</body>
</html>
