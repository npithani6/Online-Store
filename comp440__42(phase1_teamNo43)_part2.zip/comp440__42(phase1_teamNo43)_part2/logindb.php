<?php
$host = 'localhost';
$dbname = 'onlinestore';
$username = 'root';
$password = '';

try {
    // Connect to the database using MySQLi
    $mysqli = new mysqli($host, $username, $password, $dbname);
    
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Get user input and sanitize it
    $username = $mysqli->real_escape_string($_POST['username']);
    $password = $mysqli->real_escape_string($_POST['password']);
    
    $remember_me = isset($_POST['remember_me']) ? $_POST['remember_me'] : false;
    
    // Create a prepared statement
    $stmt = $mysqli->prepare("SELECT password FROM usersdata WHERE username = ?");
    $stmt->bind_param('s', $username); // 's' represents a string
    
    // Execute the prepared statement
    $stmt->execute();
    
    // Bind the result
    $stmt->bind_result($hashedPassword);
    
    // Fetch the result
    $stmt->fetch();
    
    // Verify the password
    if (password_verify($password, $hashedPassword)) {
        session_start();
        // Password is correct, create a session
        $_SESSION['username'] = $username;

        if ($remember_me) {
            $cookie_name = 'remember_me_cookie';
            $cookie_value = $username; 
            setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); 
        }
        
        // Redirect to a dashboard or success page
        header("Location: search_category.php");
        exit();
    } else {
        // Invalid credentials, redirect back to the login page with an error message
        header("Location: login.php?error=1");
        exit();
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $mysqli->close();
} catch (Exception $e) {
    // Handle database errors
    echo "Error: " . $e->getMessage();
}
?>
