

# Online-Store
Comp 440 project Online Store-Phase or Part2

# Team 42 now, team numbers were changed, it was 43 at phase 1 time.
# Team Members:
    Raviteja Pothala:
	   After typing in a category, which returns all of the items in that category, written code to write a review for the chosen item from the list that the search interface form returns in the manner described below:
          1. Drop-down menu with the options "excellent/good/fair/poor".
          2. Description of the item
	   Written code such that a user could not review his own products and could only submit up to three reviews per day.
	   Written code to implement a button called "Initialize Database."  All required tables are automatically created (or recreated) when a user clicks it. Each table are filled with a minimum of five tuples.
	  
    Srilakshmi Prasanna Nikhitha Pithani:
	   Implemented an interface for user to insert an item including Title, Description, Category and Price values.
	   Written code such that a user can only post 3 items a day.
	   Written code to generate the IDs of items automatically using autoincrement feature of MySQL.	
	
	Udaya Kesava Sai Praneeth Jonnalagedda:
	   Created a form-based search interface that returns all items in a given category after a single type in that category.
	   Written code to display the results as a table on the web-page.
	  


# Youtube Url:

# Google Drive link: 
    
