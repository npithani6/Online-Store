<?php
session_start();
require_once('db_connection.php');
require('header.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a user is selected to be marked as favorite
    if (isset($_POST['favorite_user'])) {
        $favoriteUser = $_POST['favorite_user'];

        // Insert the favorite user into the database
        $insertQuery = "INSERT INTO favorites (username, favorited_user) VALUES ('{$_SESSION['username']}', '$favoriteUser')";
        if ($conn->query($insertQuery)) {
            echo "Marked as favorite!";
        } else {
            echo "Error marking as favorite: " . $conn->error;
        }
        $conn->query($insertQuery);
        
    }
}

// Fetch all users except the logged-in user
$fetchUsersQuery = "SELECT username FROM usersdata WHERE username != '{$_SESSION['username']}'";
$usersResult = $conn->query($fetchUsersQuery);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Favorites</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <h1>Favorites</h1>
    <form method="post">
        <label for="favorite_user">Select user to mark as favorite:</label>
        <select name="favorite_user">
            <?php
            while ($row = $usersResult->fetch_assoc()) {
                echo "<option value=\"{$row['username']}\">{$row['username']}</option>";
            }
            ?>
        </select>
        <input type="submit" value="Mark as Favorite">
    </form>
</body>
</html>
