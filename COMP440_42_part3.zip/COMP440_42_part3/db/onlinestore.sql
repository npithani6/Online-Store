create database onlinestore;
USE onlinestore;
CREATE TABLE `usersdata` (
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `registrationDate` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `usersdata`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`);
COMMIT;

CREATE TABLE favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255),
    favorited_user VARCHAR(255)
);

/*INSERT INTO favorites (username, favorited_user) VALUES
('John', 'Alice'),
('John', 'Bob'),
('John', 'Charlie'),
('Jane', 'Alice'),
('Jane', 'Dave'),
('Jane', 'Eve'),
('Mike', 'Bob'),
('Mike', 'Charlie'),
('Mike', 'Eve');

CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    username VARCHAR(255) NOT NULL,  -- Updated to use username
    rating ENUM('excellent', 'good', 'fair', 'poor') NOT NULL,
    description TEXT,
    review_date DATE
);

INSERT INTO reviews (item_id, username, rating, description, review_date) VALUES
    (1, 'Anand', 'excellent', 'Great product, I love it!', '2023-11-02'),
    (1, 'Sharim', 'excellent', 'Fantastic item!', '2023-11-02'),
    (2, 'Haniya', 'excellent', 'Amazing!', '2023-11-02'),
    (2, 'Ayesha', 'excellent', 'Excellent purchase!', '2023-11-02'),
    (3, 'Fatima', 'excellent', 'Outstanding!', '2023-11-02');
    
    CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    username VARCHAR(255) NOT NULL,  -- Updated to use username
    post_date DATE
);

    INSERT INTO items (title, description, category, price, username, post_date) VALUES
    ('IPone', 'Great Phone in term of Camera', 'Smart Phone', 10000, 'Alice', '2023-05-01'),
    ('Huewei', 'Great Phone in term of battery Usage', 'Smart Phone', 15000, 'Benjamin', '2023-05-01'),
    ('One Plus', 'Great Phone in term of Gaming', 'Smart Phone', 12000, 'Steve', '2023-05-01'),
    ('Pixel ', 'Great Phone in term of Camera', 'Smart Phone', 20000, 'Alester Cook', '2023-05-01'),
    ('SamSung', 'Great Phone in term of Musical SOund', 'Smart Phone', 18000, 'John Ibraham', '2023-05-01');*/