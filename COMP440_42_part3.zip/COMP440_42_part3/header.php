<!DOCTYPE html>
<html>
<head>
    <title>Online Store</title>
    <style>
        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            margin: 0 0 20px;
            display: flex;
            justify-content: space-between;
        }

        h1 {
            margin: 0;
            
        }

        nav {
            text-align: right;
            margin-top: 10px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            margin: 10px;
        }

        nav a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1 style="color: #fff;">Online Store</h1>
        <nav>
            <a href="search_category.php">Display Items</a>
            <a href="insert_form.php">Add Item</a>
            <a href="favorites.php">Favorites</a>
            <a href="init_database.php">Init DB</a>
            <a href="part3.php">Queries Menu</a>
            <a href="logoff.php">Logoff</a>
            <!--a href="signup.php">Sign up</a-->
        </nav>
    </header>
</body>
</html>
