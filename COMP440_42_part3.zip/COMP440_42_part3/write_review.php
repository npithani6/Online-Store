<?php
session_start();
require_once('db_connection.php');
require('header.php');
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Check if the user has already given 3 reviews today
$username = $_SESSION['username'];
$today = date("Y-m-d");
$sql = "SELECT COUNT(*) as count FROM reviews WHERE username = '$username' AND review_date = '$today'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($row['count'] >= 3) {
    echo "You have already given 3 reviews today. Please try again tomorrow.";
    exit();
}

// Check if the user is trying to review their own item
$item_id = $_GET['id'];
$sql = "SELECT username FROM items WHERE id = $item_id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($row['username'] == $username) {
    echo "You cannot review your own item.";
    exit();
}

// Process the review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = $_POST['rating'];
    $description = $_POST['description'];

    $sql = "INSERT INTO reviews (item_id, username, rating, description, review_date) VALUES ($item_id, '$username', '$rating', '$description', '$today')";

    if ($conn->query($sql) === TRUE) {
        echo "Review submitted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Display the review form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Write Review</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <h2>Write a Review</h2>
    <form action="" method="post">        
        <label for="rating">Rating:</label>
        <select name="rating">
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="fair">Fair</option>
            <option value="poor">Poor</option>
        </select><br>

        <label for="description">Description:</label>
        <textarea name="description" required></textarea><br>

        <input type="submit" value="Submit Review">
    </form>
</body>
</html>
