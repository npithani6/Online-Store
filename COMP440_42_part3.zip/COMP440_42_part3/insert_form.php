<?php
session_start();
require('header.php');
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Insert Item</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <h1>Insert Item</h1>
    <form action="insert_item.php" method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" required><br>

        <label for="description">Description:</label>
        <textarea name="description" required></textarea><br>

        <label for="category">Category:</label>
        <input type="text" name="category" required><br>

        <label for="price">Price:</label>
        <input type="number" name="price" step="0.01" required><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
