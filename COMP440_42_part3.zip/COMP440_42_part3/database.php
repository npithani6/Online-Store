<?php
$host = 'localhost';
$dbname = 'onlinestore';
$username = 'root';
$password = '';

try {
    // Connect to the database using MySQLi
    $mysqli = new mysqli($host, $username, $password, $dbname);
    
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
    
    // Get user input from the signup form and sanitize it
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    
    // Hash the password using the password_hash() function
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Check if the username already exists
    $stmt = $mysqli->prepare("SELECT username FROM usersdata WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        header("Location: signup.php?error=1"); // Username already exists
        exit();
    }
    
    // Check if the email already exists
    $stmt = $mysqli->prepare("SELECT email FROM usersdata WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        header("Location: signup.php?error=2"); // Email already exists
        exit();
    }
    
    // Prepare and execute an SQL statement to insert the user data into the database
    $stmt = $mysqli->prepare("INSERT INTO usersdata (username, password, firstName, lastName, email) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('sssss', $username, $hashedPassword, $firstName, $lastName, $email);
    
    if ($stmt->execute()) {
        // Redirect to a success page or display a success message
        header("Location: login.php?success=1");
        exit();
    } else {
        // Handle database insertion error
        header("Location: signup.php?error=3");
        exit();
    }
    
    // Close the prepared statement and database connection
    $stmt->close();
    $mysqli->close();
} catch (Exception $e) {
    // Handle database errors
    echo "Error: " . $e->getMessage();
}
?>
