<?php
session_start();
require_once('db_connection.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS onlinestore";
if ($conn->query($sql) === FALSE) {
    echo "Error creating database: " . $conn->error;
    exit();
}

// Switch to the database
$conn->select_db('onlinestore');

// Create the 'items' table
$sql = "CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    username VARCHAR(255) NOT NULL,  -- Updated to use username
    post_date DATE
)";

if ($conn->query($sql) === FALSE) {
    echo "Error creating items table: " . $conn->error;
    exit();
}

// Create the 'reviews' table
$sql = "CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    username VARCHAR(255) NOT NULL,  -- Updated to use username
    rating ENUM('excellent', 'good', 'fair', 'poor') NOT NULL,
    description TEXT,
    review_date DATE
)";
if ($conn->query($sql) === FALSE) {
    echo "Error creating reviews table: " . $conn->error;
    exit();
}

// Populate the 'items' table with sample data
$sql = "INSERT INTO items (title, description, category, price, username, post_date) VALUES
    ('Smartphone A', 'A high-end smartphone with the latest features.', 'electronic', 500, 'John Doe', '2023-11-02'),
    ('Smartphone B', 'A high-end smartphone with the latest features.', 'audio', 500, 'John Doe', '2023-11-02'),
    ('Laptop C', 'A powerful laptop for gaming and productivity.', 'electronic', 1000, 'Alice Smith', '2023-11-02'),
    ('Camera D', 'A professional-grade camera for photography enthusiasts.', 'electronics', 800, 'David Johnson', '2023-11-02'),
    ('Headphones E', 'Over-ear headphones with noise-cancellation technology.', 'audio', 150, 'Emma Wilson', '2023-11-02'),
    ('Tablet E', 'A compact tablet for entertainment and work on the go.', 'electronics', 300, 'Michael Brown', '2023-11-02'),
    ('Headphones F', 'Over-ear headphones with noise-cancellation technology.', 'electronic', 150, 'Emma Wilson', '2023-11-02')";

if ($conn->query($sql) === FALSE) {
    echo "Error populating items table: " . $conn->error;
    exit();
}

// Populate the 'reviews' table with sample data
$sql = "INSERT INTO reviews (item_id, username, rating, description, review_date) VALUES
    (1, 'john_doe', 'excellent', 'Great product, I love it!', '2023-11-02'),
    (2, 'alice_smith', 'good', 'Nice laptop for work and play.', '2023-11-02'),
    (3, 'david_johnson', 'fair', 'The camera is decent, but not exceptional.', '2023-11-02'),
    (4, 'emma_wilson', 'poor', 'The headphones have poor sound quality.', '2023-11-02'),
    (5, 'michael_brown', 'excellent', 'This tablet is fantastic and versatile.', '2023-11-02')";

if ($conn->query($sql) === FALSE) {
    echo "Error populating reviews table: " . $conn->error;
    exit();
}

echo "Database initialized successfully.";

// Close the database connection
$conn->close();

?>
