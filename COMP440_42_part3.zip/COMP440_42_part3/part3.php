<?php
session_start();
require_once('db_connection.php');
require('header.php');
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

function executeQuery($conn, $query) {
    $result = $conn->query($query);

    if ($result === false) {
        echo "Error executing query: " . $conn->error;
    } else {
        echo "<h2>Query Result:</h2>";
        echo "<table border='1'>";
        
        // Display header row
        echo "<tr>";
        foreach ($result->fetch_fields() as $field) {
            echo "<th>{$field->name}</th>";
        }
        echo "</tr>";

        // Display data rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>{$value}</td>";
            }
            echo "</tr>";
        }

        echo "</table>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store Queries</title>
    <link rel="stylesheet" href="./assets/style.css">
    <style>
        button {
            width: 30rem;
            padding: 10px 20px;
            margin: 5px;
            font-size: 16px;
            cursor: pointer;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>

</head>
<body>

<h1>Online Store Queries</h1>

<form method="post">
    <button type="submit" name="query1">1. Most Expensive Items in Each Category</button>
    <button type="submit" name="query2">2. Users with Items in Different Categories on the Same Day</button>
    <label for="category1">Category 1:</label>
    <input type="text" name="category1" >
    <label for="category2">Category 2:</label>
    <input type="text" name="category2" >
    <button type="submit" name="query3">3. Items with Excellent or Good Comments by User X</button>
    <label for="selectUser">Select User:</label>
    <select name="selectUser" >
        <!-- Fetch and display all available usernames -->
        <?php
        $usernamesQuery = "SELECT DISTINCT username FROM items";
        $usernamesResult = $conn->query($usernamesQuery);
        
        while ($row = $usernamesResult->fetch_assoc()) {
            echo "<option value=\"{$row['username']}\">{$row['username']}</option>";
        }
        ?>
    </select>
    <button type="submit" name="query4">4. Users with Most Items on a Specific Date</button>
    <label for="specificDate">Specific Date:</label>
    <input type="date" name="specificDate" >
    <button type="submit" name="query5">5. Users Favorited by Both X and Y</button>
    <label for="selectUserX">Select User X:</label>
    <select name="selectUserX">
        <?php
        $usernamesQueryX = "SELECT DISTINCT username FROM usersdata";
        $usernamesResultX = $conn->query($usernamesQueryX);

        while ($row = $usernamesResultX->fetch_assoc()) {
            echo "<option value=\"{$row['username']}\">{$row['username']}</option>";
        }
        ?>
    </select>
    <label for="selectUserY">Select User Y:</label>
    <select name="selectUserY">
        <?php
        $usernamesQueryY = "SELECT DISTINCT username FROM usersdata";
        $usernamesResultY = $conn->query($usernamesQueryY);

        while ($row = $usernamesResultY->fetch_assoc()) {
            echo "<option value=\"{$row['username']}\">{$row['username']}</option>";
        }
        ?>
    </select>
    <button type="submit" name="query6">6. Users who Never Posted Excellent Items</button>
    <button type="submit" name="query7">7. Users who Never Posted a Poor Review</button>
    <button type="submit" name="query8">8. Users with Only Poor Reviews</button>
    <button type="submit" name="query9">9. Users with Items Never Receiving Poor Reviews</button>
    <button type="submit" name="query10">10. Users Always Giving Each Other Excellent Reviews</button>
</form>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["query1"])) {
        $query = "SELECT MAX(id) AS id, title, description, category, MAX(price) AS price, username, MAX(post_date) AS post_date
        FROM items i
        WHERE (category, price) IN (
            SELECT category, MAX(price) AS max_price
            FROM items
            GROUP BY category
        ) 
        GROUP BY title, description, category, username
        ORDER BY category, price DESC 
        ";
        executeQuery($conn, $query);
    } elseif (isset($_POST["query2"])) {
        // Get category inputs from the form
        $category1 = $_POST["category1"];
        $category2 = $_POST["category2"];
        
        $query = "SELECT username
        FROM items
        WHERE category IN ('$category1', '$category2')
        GROUP BY username, post_date
        HAVING COUNT(DISTINCT category) = 2
        ";
        executeQuery($conn, $query);

    } elseif (isset($_POST["query3"])) {
        $selectedUser = $_POST["selectUser"];
        $query = "SELECT i.*
        FROM items i
        JOIN reviews r ON i.id = r.item_id
        WHERE i.username = '$selectedUser' AND r.rating IN ('excellent', 'good')
        AND i.id NOT IN (
            SELECT item_id
            FROM reviews
            WHERE item_id = i.id AND rating IN ('poor', 'fair')
        )
        GROUP BY i.id
        ";
        executeQuery($conn, $query);

    } elseif (isset($_POST["query4"])) {
        $specificDate = $_POST["specificDate"];
        $query = "SELECT username
        FROM items
        WHERE post_date = '$specificDate'
        GROUP BY username
        HAVING COUNT(*) = (
            SELECT COUNT(*)
            FROM items
            WHERE post_date = '$specificDate'
            GROUP BY username
            ORDER BY COUNT(*) DESC
            LIMIT 1
        )
        ";
        executeQuery($conn, $query);

    } elseif (isset($_POST["query5"])) {
        $selectedUserX = $_POST["selectUserX"];
        $selectedUserY = $_POST["selectUserY"];
        $query = "SELECT DISTINCT f1.favorited_user
        FROM favorites f1
        JOIN favorites f2 ON f1.favorited_user = f2.favorited_user
        WHERE f1.username = '$selectedUserX' AND f2.username = '$selectedUserY'";
        executeQuery($conn, $query);

    } elseif (isset($_POST["query6"])) {
        $query = "SELECT DISTINCT username
            FROM items
            WHERE username NOT IN (
                SELECT i.username
                FROM items i
                JOIN reviews r ON i.id = r.item_id
                WHERE r.rating = 'excellent'
                GROUP BY i.username
                HAVING COUNT(*) >= 3
            )";
        executeQuery($conn, $query);
    
    

    } elseif (isset($_POST["query7"])) {
        $query = "SELECT DISTINCT username
        FROM reviews r
        WHERE NOT EXISTS (
            SELECT 1
            FROM reviews
            WHERE username = r.username AND rating = 'poor'
        )";
        executeQuery($conn, $query);
        


    } elseif (isset($_POST["query8"])) {
        $query = "SELECT DISTINCT username
        FROM reviews
        GROUP BY username
        HAVING COUNT(DISTINCT rating) = 1 AND MAX(rating) = 'poor'
        ";
        executeQuery($conn, $query);

    } elseif (isset($_POST["query9"])) {
        $query = "SELECT DISTINCT i.username
        FROM items i
        LEFT JOIN reviews r ON i.id = r.item_id AND r.rating = 'poor'
        GROUP BY i.username
        HAVING COUNT(DISTINCT i.id) = COUNT(DISTINCT CASE WHEN r.rating IS NULL THEN i.id END)
        ";
        executeQuery($conn, $query);
        
    }

    elseif (isset($_POST["query10"])) {
        $query = "SELECT U1.username AS USER_A, U2.username AS USER_B
        FROM usersdata U1, usersdata U2
        WHERE U1.username < U2.username
        AND NOT EXISTS (
            SELECT 1
            FROM items P1
            LEFT JOIN reviews R1 ON P1.id = R1.item_id AND R1.username = U2.username
            WHERE P1.username = U1.username AND (R1.rating IS NULL OR R1.rating <> 'excellent')
        )
        AND NOT EXISTS (
            SELECT 1
            FROM items P2
            LEFT JOIN reviews R2 ON P2.id = R2.item_id AND R2.username = U1.username
            WHERE P2.username = U2.username AND (R2.rating IS NULL OR R2.rating <> 'Excellent')
        
        )    AND U1.username IN (SELECT DISTINCT username FROM reviews)
AND U2.username IN (SELECT DISTINCT username FROM reviews);"; 
        executeQuery($conn, $query);
    }
    
}

$conn->close();

?>

</body>
</html>
