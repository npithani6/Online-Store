<?php
    session_start();
     if(!isset($_SESSION['username'])) {
        header("Location: login.php");
     }
     else
     {
      $username=$_SESSION['username'];
    
     }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome Page</title>
    <style>
        body {
            background-image: url('https://cdn.vectorstock.com/i/1000x1000/52/75/online-shopping-black-banner-or-promotion-vector-35015275.webp');
            background-size: cover; 
            background-position:center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 120vh;
            margin: 0;
        }
        h1 {
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        .homepage {
            background-color: white;
            padding: 20px;
            border: 2px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="homepage">
        <h1>Welcome to Online Shopping - <?php echo $username  ;?></h1>
    </div>
</body>
</html>
