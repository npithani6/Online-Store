<?php
    session_start();
    session_destroy();
    header("Location: login.php");
    exit(); // Add exit to prevent further code execution
?>
