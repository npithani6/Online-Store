<?php
// Include your database connection configuration here
$host = 'localhost';
$dbname = 'storedb';
$username = 'root';
$password = '';

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get user input from the signup form
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    /*
    form validation
    if (empty($firstName) || empty($lastName) || empty($username) || empty($password) || empty($email)) {
        header("Location: signup.php?error=4"); // Fields are empty
        exit();
    } 
    */
    // Hash the password using the password_hash() function
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("SELECT * FROM usersdata WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();

    /* 
    
    // Password strength check

      // Hash the password using the password_hash() function
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    if (strlen($password) < 8 || !preg_match("/\d/", $password) || !preg_match("/[A-Z]/", $password)) {
        header("Location: signup.php?error=5"); // Weak password
        exit();
    }
    
    */
    
    // Fetch the user information if found
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user)
    {
        header("Location: signup.php?error=1");
    }
    $stmt = $pdo->prepare("SELECT * FROM usersdata WHERE email = :username");
    $stmt->bindParam(':username', $email);
    $stmt->execute();
    /*
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT * FROM usersdata WHERE username = :username OR email = :email");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    // Fetch the user information if found
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if ($user['username'] == $username) {
            header("Location: signup.php?error=1"); // Username already exists
        } elseif ($user['email'] == $email) {
            header("Location: signup.php?error=2"); // Email already exists
        }
        exit();
    }

    */
  // Fetch the user information if found
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user)
    {
        header("Location: signup.php?error=2");
    }
    // Prepare and execute an SQL statement to insert the user data into the database
    $stmt = $pdo->prepare("INSERT INTO usersdata (username, password, firstName, lastName, email) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$username, $hashedPassword, $firstName, $lastName, $email]);
    
    // Redirect to a success page or display a success message
    header("Location: login.php?error=3");
    exit();
} catch (PDOException $e) {
    // Handle database errors (e.g., duplicate username)
    echo "Error: " . $e->getMessage();
}

?>

