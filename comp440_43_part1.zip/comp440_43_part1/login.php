
<?php
     if(isset($_SESSION['username'])) {
        header("Location: welcome.php");
     }
     ?>
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image:url('https://as1.ftcdn.net/v2/jpg/02/34/09/24/1000_F_234092401_jv2JZDvES6zocvLxNyVxoMDOGvRzg4rG.jpg');
            /* background-image: linear-gradient(to right top, #051937, #004d7a, #008793, #00bf72, #a8eb12); */
            margin: 0;
            padding: 0;
            
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            width: 400px;
            padding: 20px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 15px;
            margin: 10px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            position: relative;
        }

       

        .button-container {
            text-align: center;
        }

        .button {
            padding: 15px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #00ff00;
        }

        .signup-link {
            margin-top: 15px;
            display: block;
            font-size: 14px;
            color: #00ff00;
            text-decoration: none;
        }

        .signup-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

        
    <div class="container">
    <?php
     if(isset($_GET["error"])) {
        if($_GET["error"] ==1){
        echo "<p style='color:red;'>Invalid Login credentials</p><br>";}
        if($_GET["error"] ==3){
            echo "<p style='color:green;'>User Successfully Registered</p><br>";}
        }
        ?>
        <h2>Login Page</h2>
        <form action="logindb.php" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <br>
            <div style="position: relative;">
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <div class="button-container">
                <button type="submit" class="button">Log In</button>
                <a href="signup.php" class="signup-link">New User? Sign Up</a>
            </div>
        </form>
    </div>

</body>
</html>
